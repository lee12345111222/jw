import Unity from '../whitelist/Unity';
import Editor from './Editor';

export default function Index() {
  return (
    <Unity>
      <Editor />
    </Unity>
  );
}
