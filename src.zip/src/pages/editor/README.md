## Editor

- login_token
- space_uuid
- name
- address
