import PartDetail from './PartDetail';
import GenesisDetail from './GenesisDetail';
import BlueprintDetail from './BlueprintDetail';
import AircraftDetail from './AircraftDetail';

export { PartDetail, GenesisDetail, BlueprintDetail, AircraftDetail };
