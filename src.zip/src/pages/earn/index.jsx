import MainPage from '@/components/MainPage/index';

import Coming from '@/components/Coming';

export default function Earn() {
  return (
    <MainPage title="Earn">
      <Coming />
    </MainPage>
  );
}
