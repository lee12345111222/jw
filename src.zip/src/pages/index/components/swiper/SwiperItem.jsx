// import { makeStyles } from "@material-ui/core/styles";

// import { Swiper, SwiperSlide } from "swiper/react";
// import SwiperCore, { Navigation } from "swiper";

// import "swiper/swiper.scss";

// import "swiper/components/navigation/navigation.scss";
// import "swiper/components/pagination/pagination.scss";
// import "./swiper.css";

// SwiperCore.use([Navigation]);

// const styles = makeStyles({
//   box: {
//     marginBottom: "72px",
//   },
//   item: {
//     backgroundColor: "rgba(255, 255, 255, .4)",
//   },
// });

// export default function SwiperItem() {
//   const classes = styles();

//   return (
//     <Swiper
//       spaceBetween={30}
//       slidesPerView={3}
//       centeredSlides={true}
//       loop={true}
//       navigation
//       onSlideChange={() => {}}
//       onSwiper={(swiper) => {}}
//     >
//       <SwiperSlide>
//       </SwiperSlide>
//       <SwiperSlide>
//         <div className={classes.item}>Slide 2</div>
//       </SwiperSlide>
//       <SwiperSlide>
//         <div className={classes.item}>Slide 3</div>
//       </SwiperSlide>
//       <SwiperSlide>
//         <div className={classes.item}>Slide 4</div>
//       </SwiperSlide>
//     </Swiper>
//   );
// }

export default function SwiperItem() {
  return <div></div>;
}
