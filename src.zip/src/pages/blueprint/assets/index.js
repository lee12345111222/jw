export { default as imageIcon } from './image-icon.svg';
export { default as nameIcon } from './name-icon.svg';
export { default as styleIcon } from './style-icon.svg';
export { default as archIcon } from './arch-icon.svg';
export { default as issueIcon } from './issue-icon.svg';
export { default as descIcon } from './desc-icon.svg';
