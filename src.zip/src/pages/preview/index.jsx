import WalletOrGuest from './WalletOrGuest';

export default function Index() {
  return <WalletOrGuest />;
}
