export const menuList = [
  // {
  //   title: 'start',
  //   url: '/'
  // },
  {
    title: 'create',
    url: '/create/space'
    // isHot: true
  },
  {
    title: 'map',
    url: '/map'
  },
  {
    title: 'market',
    url: '/market/parcel'
    // isHot: true
  },

  {
    title: 'discover',
    url: '/discover'
  },
  // {
  //   title: 'earn',
  //   url: '/earn'
  // },
  {
    title: 'event',
    url: '/mysterybox'
    // isHot: true
  },
  {
    title: 'airdrop',
    url: '/airdrop'
    // isHot: true
  }
];
