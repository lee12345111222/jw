module.exports = {
  login_sign_str: `Welcome to PlayerOne!
Click "Sign" to sign in. No password needed!
I accept the PlayerOne Terms of Service: https://playerone.world/tos
ADDRESS `,
  supported_chains: { ethereum: 5, polygon: 80001 }
};
