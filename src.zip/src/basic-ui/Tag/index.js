export { default as Tag } from './Tag';
